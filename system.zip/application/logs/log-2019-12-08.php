<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-08 10:57:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-08 10:57:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-08 11:59:26 --> Severity: error --> Exception: Call to undefined method Admin_model::languages_get() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/api/Admin.php 28
