<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-24 08:37:43 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/libraries/Session/Session.php 136
ERROR - 2021-01-24 08:37:43 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/database/DB_query_builder.php 2418
ERROR - 2021-01-24 14:37:43 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/database/DB_query_builder.php 2418
ERROR - 2021-01-24 14:41:01 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/database/DB_query_builder.php 2418
ERROR - 2021-01-24 14:44:20 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/helpers/url_helper.php 534
ERROR - 2021-01-24 08:45:47 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/core/URI.php 328
ERROR - 2021-01-24 08:45:47 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/libraries/Session/Session.php 136
ERROR - 2021-01-24 08:45:47 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/database/DB_query_builder.php 2418
ERROR - 2021-01-24 08:45:57 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/core/URI.php 328
ERROR - 2021-01-24 08:49:11 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/core/URI.php 328
ERROR - 2021-01-24 08:49:12 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/libraries/Session/Session.php 136
ERROR - 2021-01-24 08:49:12 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/database/DB_query_builder.php 2418
ERROR - 2021-01-24 09:06:58 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/core/URI.php 328
ERROR - 2021-01-24 09:06:58 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/libraries/Session/Session.php 136
ERROR - 2021-01-24 09:06:58 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/database/DB_query_builder.php 2418
ERROR - 2021-01-24 15:09:44 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/database/DB_query_builder.php 2418
ERROR - 2021-01-24 16:03:38 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 16
ERROR - 2021-01-24 16:03:38 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 17
ERROR - 2021-01-24 16:03:38 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 18
ERROR - 2021-01-24 16:03:38 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 19
ERROR - 2021-01-24 16:03:38 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 19
ERROR - 2021-01-24 16:03:38 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 20
ERROR - 2021-01-24 16:03:38 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 21
ERROR - 2021-01-24 16:03:38 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 22
ERROR - 2021-01-24 16:03:38 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 23
ERROR - 2021-01-24 16:03:38 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 24
ERROR - 2021-01-24 16:03:38 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 25
ERROR - 2021-01-24 16:03:38 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 28
ERROR - 2021-01-24 16:03:38 --> Severity: Warning --> include(.php): failed to open stream: No such file or directory /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 28
ERROR - 2021-01-24 16:03:38 --> Severity: Warning --> include(): Failed opening '.php' for inclusion (include_path='.:/Applications/MAMP/bin/php/php7.3.1/lib/php') /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 28
ERROR - 2021-01-24 16:03:45 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 16
ERROR - 2021-01-24 16:03:45 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 17
ERROR - 2021-01-24 16:03:45 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 18
ERROR - 2021-01-24 16:03:45 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 19
ERROR - 2021-01-24 16:03:45 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 19
ERROR - 2021-01-24 16:03:45 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 20
ERROR - 2021-01-24 16:03:45 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 21
ERROR - 2021-01-24 16:03:45 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 22
ERROR - 2021-01-24 16:03:45 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 23
ERROR - 2021-01-24 16:03:45 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 24
ERROR - 2021-01-24 16:03:45 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 25
ERROR - 2021-01-24 16:03:45 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 28
ERROR - 2021-01-24 16:03:45 --> Severity: Warning --> include(.php): failed to open stream: No such file or directory /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 28
ERROR - 2021-01-24 16:03:45 --> Severity: Warning --> include(): Failed opening '.php' for inclusion (include_path='.:/Applications/MAMP/bin/php/php7.3.1/lib/php') /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 28
ERROR - 2021-01-24 16:04:01 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 16
ERROR - 2021-01-24 16:04:01 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 17
ERROR - 2021-01-24 16:04:01 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 18
ERROR - 2021-01-24 16:04:01 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 19
ERROR - 2021-01-24 16:04:01 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 19
ERROR - 2021-01-24 16:04:01 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 20
ERROR - 2021-01-24 16:04:01 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 21
ERROR - 2021-01-24 16:04:01 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 22
ERROR - 2021-01-24 16:04:01 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 23
ERROR - 2021-01-24 16:04:01 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 24
ERROR - 2021-01-24 16:04:01 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 25
ERROR - 2021-01-24 16:04:01 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 28
ERROR - 2021-01-24 16:04:01 --> Severity: Warning --> include(.php): failed to open stream: No such file or directory /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 28
ERROR - 2021-01-24 16:04:01 --> Severity: Warning --> include(): Failed opening '.php' for inclusion (include_path='.:/Applications/MAMP/bin/php/php7.3.1/lib/php') /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 28
ERROR - 2021-01-24 16:04:04 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 16
ERROR - 2021-01-24 16:04:04 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 17
ERROR - 2021-01-24 16:04:04 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 18
ERROR - 2021-01-24 16:04:04 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 19
ERROR - 2021-01-24 16:04:04 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 19
ERROR - 2021-01-24 16:04:04 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 20
ERROR - 2021-01-24 16:04:04 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 21
ERROR - 2021-01-24 16:04:04 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 22
ERROR - 2021-01-24 16:04:04 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 23
ERROR - 2021-01-24 16:04:04 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 24
ERROR - 2021-01-24 16:04:04 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 25
ERROR - 2021-01-24 16:04:04 --> Severity: Notice --> Undefined variable: page_content /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 28
ERROR - 2021-01-24 16:04:04 --> Severity: Warning --> include(.php): failed to open stream: No such file or directory /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 28
ERROR - 2021-01-24 16:04:04 --> Severity: Warning --> include(): Failed opening '.php' for inclusion (include_path='.:/Applications/MAMP/bin/php/php7.3.1/lib/php') /Applications/MAMP/htdocs/ekattor_7.2/application/views/backend/superadmin/website_settings/index.php 28
ERROR - 2021-01-24 16:35:18 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/helpers/url_helper.php 534
ERROR - 2021-01-24 16:47:26 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/helpers/url_helper.php 534
ERROR - 2021-01-24 10:50:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2021-01-24 11:25:19 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/core/URI.php 328
ERROR - 2021-01-24 11:25:19 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/libraries/Session/Session.php 136
ERROR - 2021-01-24 11:25:19 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/database/DB_query_builder.php 2418
ERROR - 2021-01-24 11:34:08 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/core/URI.php 328
ERROR - 2021-01-24 11:34:08 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/database/DB_query_builder.php 2418
ERROR - 2021-01-24 17:38:34 --> Severity: Notice --> Undefined variable: key /Applications/MAMP/htdocs/ekattor_7.2/application/helpers/common_helper.php 25
ERROR - 2021-01-24 17:38:34 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `settings`
WHERE `type` IS NULL
ERROR - 2021-01-24 17:38:59 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `settings`
WHERE `type` = 'recaptcha_status'
ERROR - 2021-01-24 17:39:38 --> Severity: Notice --> Undefined index: recaptcha_status /Applications/MAMP/htdocs/ekattor_7.2/application/helpers/common_helper.php 61
ERROR - 2021-01-24 17:39:38 --> Severity: Notice --> Undefined index: recaptcha_status /Applications/MAMP/htdocs/ekattor_7.2/application/helpers/common_helper.php 61
ERROR - 2021-01-24 17:39:38 --> Severity: Notice --> Undefined index: recaptcha_sitekey /Applications/MAMP/htdocs/ekattor_7.2/application/helpers/common_helper.php 61
ERROR - 2021-01-24 17:39:38 --> Severity: Notice --> Undefined index: recaptcha_secretkey /Applications/MAMP/htdocs/ekattor_7.2/application/helpers/common_helper.php 61
ERROR - 2021-01-24 11:51:07 --> 404 Page Not Found: Superadmin/recaptcha_settings
ERROR - 2021-01-24 11:51:16 --> 404 Page Not Found: Superadmin/recaptcha_settings
ERROR - 2021-01-24 11:51:25 --> 404 Page Not Found: Superadmin/recaptcha_settings
ERROR - 2021-01-24 11:51:54 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/database/DB_query_builder.php 696
ERROR - 2021-01-24 11:51:54 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/database/DB_query_builder.php 2418
ERROR - 2021-01-24 18:01:46 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/helpers/url_helper.php 534
ERROR - 2021-01-24 18:01:48 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/helpers/url_helper.php 534
ERROR - 2021-01-24 18:02:13 --> Severity: Notice --> Undefined index: recaptcha_status /Applications/MAMP/htdocs/ekattor_7.2/application/helpers/common_helper.php 61
ERROR - 2021-01-24 12:02:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2021-01-24 12:03:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2021-01-24 12:08:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2021-01-24 12:09:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2021-01-24 18:09:19 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/helpers/url_helper.php 534
ERROR - 2021-01-24 12:09:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2021-01-24 12:09:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2021-01-24 12:10:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2021-01-24 12:12:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2021-01-24 18:13:28 --> Severity: Warning --> filter_var(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/libraries/Email.php 1873
ERROR - 2021-01-24 12:28:54 --> 404 Page Not Found: addons/Assignment/answer_and_mark
ERROR - 2021-01-24 18:29:00 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/database/DB_query_builder.php 2418
ERROR - 2021-01-24 12:32:17 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/database/DB_query_builder.php 696
ERROR - 2021-01-24 12:32:17 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/database/DB_query_builder.php 2418
ERROR - 2021-01-24 18:32:29 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/database/DB_query_builder.php 2418
