<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-15 05:21:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-15 05:21:50 --> Unable to connect to the database
ERROR - 2019-12-15 06:15:38 --> Severity: Notice --> Undefined index: class_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 889
ERROR - 2019-12-15 06:15:38 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 890
ERROR - 2019-12-15 06:15:38 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/student/invoice/list.php 17
ERROR - 2019-12-15 06:21:16 --> Severity: Notice --> Undefined variable: invoice_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/attendance/list.php 2
ERROR - 2019-12-15 06:21:16 --> Severity: Notice --> Undefined index: class_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 889
ERROR - 2019-12-15 06:21:16 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 890
ERROR - 2019-12-15 06:37:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-12-15 06:38:11 --> Severity: error --> Exception: Unable to locate the model you have specified: Multischool_model /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/core/Loader.php 348
ERROR - 2019-12-15 08:07:56 --> Severity: Warning --> unlink(uploads/syllabus/b9ee402311d967f629e9917582c09f52.): No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Crud_model.php 359
ERROR - 2019-12-15 08:15:15 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/invoice/list.php 37
ERROR - 2019-12-15 08:22:01 --> 404 Page Not Found: Admin/admin
ERROR - 2019-12-15 08:27:31 --> 404 Page Not Found: Admin/website_settings
ERROR - 2019-12-15 08:27:51 --> 404 Page Not Found: Admin/website_settings
ERROR - 2019-12-15 08:28:00 --> 404 Page Not Found: Admin/addon_manager
ERROR - 2019-12-15 08:50:05 --> 404 Page Not Found: Parents/class_wise_subject
ERROR - 2019-12-15 08:50:08 --> 404 Page Not Found: Parents/class_wise_subject
ERROR - 2019-12-15 08:50:11 --> 404 Page Not Found: Parents/class_wise_subject
ERROR - 2019-12-15 08:50:14 --> 404 Page Not Found: Parents/class_wise_subject
ERROR - 2019-12-15 08:50:22 --> 404 Page Not Found: Parents/class_wise_subject
ERROR - 2019-12-15 09:41:56 --> Query error: Unknown column 'mark_from' in 'where clause' - Invalid query: SELECT *
FROM `settings`
WHERE `mark_from` <= '84'
AND `mark_upto` >= '84'
AND `id` = 1
ERROR - 2019-12-15 09:42:13 --> Query error: Unknown column 'mark_from' in 'where clause' - Invalid query: SELECT *
FROM `settings`
WHERE `mark_from` <= '84'
AND `mark_upto` >= '84'
AND `id` = 1
ERROR - 2019-12-15 09:42:25 --> Query error: Unknown column 'mark_from' in 'where clause' - Invalid query: SELECT *
FROM `settings`
WHERE `mark_from` <= '84'
AND `mark_upto` >= '84'
AND `id` = 1
ERROR - 2019-12-15 09:49:45 --> Query error: Unknown column 'mark_from' in 'where clause' - Invalid query: SELECT *
FROM `settings`
WHERE `mark_from` <= '84'
AND `mark_upto` >= '84'
AND `id` = 1
ERROR - 2019-12-15 09:49:56 --> Query error: Unknown column 'mark_from' in 'where clause' - Invalid query: SELECT *
FROM `settings`
WHERE `mark_from` <= '84'
AND `mark_upto` >= '84'
AND `id` = 1
ERROR - 2019-12-15 10:00:10 --> Severity: Notice --> Undefined index: name /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 280
ERROR - 2019-12-15 10:00:10 --> Severity: Notice --> Undefined index: grade_point /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 280
ERROR - 2019-12-15 10:00:10 --> Severity: Notice --> Undefined index: name /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 280
ERROR - 2019-12-15 10:00:10 --> Severity: Notice --> Undefined index: grade_point /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 280
ERROR - 2019-12-15 10:35:00 --> 404 Page Not Found: Parents/language
ERROR - 2019-12-15 10:35:01 --> 404 Page Not Found: Parents/language
ERROR - 2019-12-15 10:35:27 --> 404 Page Not Found: Parents/language
ERROR - 2019-12-15 11:34:49 --> Severity: Notice --> Undefined variable: cover_image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/gallery.php 53
ERROR - 2019-12-15 11:36:10 --> Severity: Notice --> Undefined variable: cover_image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/gallery.php 53
ERROR - 2019-12-15 11:37:53 --> Severity: Notice --> Undefined variable: cover_image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/gallery.php 53
ERROR - 2019-12-15 11:37:55 --> Severity: Notice --> Undefined variable: cover_image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/gallery.php 53
ERROR - 2019-12-15 11:37:56 --> Severity: Notice --> Undefined variable: cover_image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/gallery.php 53
ERROR - 2019-12-15 11:37:56 --> Severity: Notice --> Undefined variable: cover_image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/gallery.php 53
ERROR - 2019-12-15 11:37:56 --> Severity: Notice --> Undefined variable: cover_image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/gallery.php 53
ERROR - 2019-12-15 11:37:56 --> Severity: Notice --> Undefined variable: cover_image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/gallery.php 53
ERROR - 2019-12-15 11:37:56 --> Severity: Notice --> Undefined variable: cover_image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/gallery.php 53
ERROR - 2019-12-15 11:37:56 --> Severity: Notice --> Undefined variable: cover_image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/gallery.php 53
ERROR - 2019-12-15 11:37:56 --> Severity: Notice --> Undefined variable: cover_image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/gallery.php 53
ERROR - 2019-12-15 11:37:56 --> Severity: Notice --> Undefined variable: cover_image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/gallery.php 53
ERROR - 2019-12-15 11:37:56 --> Severity: Notice --> Undefined variable: cover_image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/gallery.php 53
ERROR - 2019-12-15 11:37:57 --> Severity: Notice --> Undefined variable: cover_image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/gallery.php 53
ERROR - 2019-12-15 11:38:00 --> Severity: Notice --> Undefined variable: cover_image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/gallery.php 53
ERROR - 2019-12-15 11:38:01 --> Severity: Notice --> Undefined variable: cover_image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/gallery.php 53
ERROR - 2019-12-15 13:31:46 --> Query error: Unknown column 'school_id' in 'where clause' - Invalid query: SELECT *
FROM `sessions`
WHERE `school_id` = '1'
ERROR - 2019-12-15 13:31:54 --> Query error: Unknown column 'school_id' in 'where clause' - Invalid query: SELECT *
FROM `sessions`
WHERE `school_id` = '1'
ERROR - 2019-12-15 13:32:07 --> Query error: Unknown column 'school_id' in 'where clause' - Invalid query: SELECT *
FROM `sessions`
WHERE `school_id` = '1'
ERROR - 2019-12-15 13:32:21 --> Query error: Unknown column 'school_id' in 'where clause' - Invalid query: SELECT *
FROM `sessions`
WHERE `school_id` = '1'
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: class_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 889
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 890
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 33
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 36
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 47
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 48
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 51
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 52
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: class_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 889
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 890
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 33
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 36
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 47
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 48
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 51
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 52
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: class_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 889
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 890
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 33
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 36
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 47
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 48
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 51
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 52
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: class_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 889
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 890
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 33
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 36
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 47
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 48
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 51
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 52
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: class_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 889
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 890
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 33
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 36
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 47
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 48
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 51
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 52
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: class_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 889
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 890
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 33
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 36
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 47
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 48
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 51
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 52
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: class_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 889
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 890
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 33
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 36
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 47
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 48
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 51
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 52
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: class_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 889
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 890
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 33
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 36
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 47
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 48
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 51
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 52
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: class_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 889
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 890
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 33
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 36
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 47
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 48
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 51
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 52
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: class_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 889
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 890
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 33
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 36
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 47
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 48
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 51
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 52
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: class_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 889
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 890
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 33
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 36
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 47
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 48
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 51
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 52
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: class_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 889
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 890
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 33
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 36
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 47
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 48
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 51
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 52
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: class_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 889
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 890
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 33
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 36
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 47
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 48
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 51
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 52
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: class_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 889
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 890
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 33
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 36
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 47
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 48
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 51
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 52
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: class_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 889
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 890
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 33
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 36
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 47
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 48
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 51
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 52
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: class_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 889
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 890
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: section_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 33
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 36
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 47
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 48
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 51
ERROR - 2019-12-15 13:33:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/promotion/list.php 52
