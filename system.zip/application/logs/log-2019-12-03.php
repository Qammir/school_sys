ERROR - 2019-12-03 06:32:26 --> 404 Page Not Found: Uploads/image
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-03 06:32:26 --> 404 Page Not Found: Uploads/image
ERROR - 2019-12-03 06:32:26 --> 404 Page Not Found: Uploads/image
ERROR - 2019-12-03 06:32:48 --> 404 Page Not Found: Uploads/image
ERROR - 2019-12-03 06:32:48 --> 404 Page Not Found: Uploads/image
ERROR - 2019-12-03 06:32:48 --> 404 Page Not Found: Uploads/image
ERROR - 2019-12-03 06:44:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-12-03 06:44:42 --> 404 Page Not Found: Uploads/image
ERROR - 2019-12-03 06:45:47 --> 404 Page Not Found: Uploads/image
ERROR - 2019-12-03 06:45:47 --> 404 Page Not Found: Uploads/image
ERROR - 2019-12-03 06:45:47 --> 404 Page Not Found: Uploads/image
ERROR - 2019-12-03 06:47:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-12-03 07:19:17 --> Severity: Warning --> require(/Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application//libraries/TokenHandler.php): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/api/Admin.php 2
ERROR - 2019-12-03 07:19:17 --> Severity: Compile Error --> require(): Failed opening required '/Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application//libraries/TokenHandler.php' (include_path='.:/usr/local/Cellar/php@7.2/7.2.13/share/php@7.2/pear') /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/api/Admin.php 2
ERROR - 2019-12-03 07:21:13 --> Severity: Warning --> require(/Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application//libraries/JWT.php): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/libraries/JWT/TokenHandler.php 2
ERROR - 2019-12-03 07:21:13 --> Severity: Compile Error --> require(): Failed opening required '/Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application//libraries/JWT.php' (include_path='.:/usr/local/Cellar/php@7.2/7.2.13/share/php@7.2/pear') /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/libraries/JWT/TokenHandler.php 2
ERROR - 2019-12-03 07:24:20 --> 404 Page Not Found: api/Admin/LoginToken_get
ERROR - 2019-12-03 07:28:41 --> Severity: error --> Exception: Too few arguments to function Admin::token_data_get(), 0 passed in /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/libraries/REST_Controller.php on line 788 and exactly 1 expected /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/api/Admin.php 320
ERROR - 2019-12-03 08:07:48 --> Severity: Notice --> Undefined property: Admin::$api_model /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/api/Admin.php 68
ERROR - 2019-12-03 08:07:48 --> Severity: error --> Exception: Call to a member function login_get() on null /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/api/Admin.php 68
ERROR - 2019-12-03 08:08:54 --> Severity: Notice --> Undefined property: Admin::$api_model /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/api/Admin.php 68
ERROR - 2019-12-03 08:08:54 --> Severity: error --> Exception: Call to a member function login_get() on null /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/api/Admin.php 68
ERROR - 2019-12-03 08:09:06 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT *
FROM `users`
WHERE `email` = 'admin@example.com'
AND `password` = '7110eda4d09e062aa5e4a390b0a572ac0d2c0220'
AND `status` = 1
ERROR - 2019-12-03 08:10:30 --> Severity: error --> Exception: Call to undefined function get_user_role() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 31
ERROR - 2019-12-03 08:56:47 --> Severity: error --> Exception: Call to undefined method Admin_model::userdata_get() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/api/Admin.php 281
ERROR - 2019-12-03 09:03:15 --> Severity: Notice --> Undefined variable: response /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 60
ERROR - 2019-12-03 09:04:09 --> Severity: error --> Exception: Class 'SignatureInvalidException' not found /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/libraries/JWT.php 112
ERROR - 2019-12-03 09:06:42 --> Severity: error --> Exception: Class 'SignatureInvalidException' not found /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/libraries/JWT.php 112
ERROR - 2019-12-03 11:40:42 --> Severity: error --> Exception: Call to undefined function api_school_id() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 112
ERROR - 2019-12-03 11:41:00 --> Severity: error --> Exception: Using $this when not in object context /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/api_helper.php 16
ERROR - 2019-12-03 11:58:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-03 11:58:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-03 11:58:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-03 11:59:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-03 12:09:38 --> Query error: Unknown column 'address' in 'field list' - Invalid query: INSERT INTO `sessions` (`name`, `address`, `phone`, `school_id`, `status`) VALUES ('2018-2019', 'She-E-Bangla Nagar, Dhaka', '+0285475575', 11, 1)
ERROR - 2019-12-03 12:09:45 --> Query error: Unknown column 'address' in 'field list' - Invalid query: INSERT INTO `sessions` (`name`, `address`, `phone`, `school_id`, `status`) VALUES ('2018-2019', NULL, NULL, 12, 1)
ERROR - 2019-12-03 12:11:40 --> Query error: Duplicate entry '2018-2019' for key 'name' - Invalid query: INSERT INTO `sessions` (`name`, `school_id`, `status`) VALUES ('2018-2019', 13, 1)
ERROR - 2019-12-03 12:42:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-03 12:42:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-03 12:45:19 --> Severity: error --> Exception: Call to undefined function 14() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 114
