<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-18 05:29:50 --> Query error: Column 'name' cannot be null - Invalid query: INSERT INTO `addons` (`name`, `unique_identifier`, `version`, `status`, `created_at`) VALUES (NULL, NULL, NULL, 1, 1542585600)
ERROR - 2019-11-18 07:38:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-18 07:38:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-18 07:49:18 --> 404 Page Not Found: addons/Alumni/events
ERROR - 2019-11-18 09:06:44 --> Severity: Warning --> substr() expects parameter 3 to be integer, string given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 227
ERROR - 2019-11-18 09:07:07 --> Severity: Warning --> substr() expects parameter 3 to be integer, string given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 227
ERROR - 2019-11-18 09:07:26 --> Severity: Warning --> substr() expects parameter 3 to be integer, string given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 227
ERROR - 2019-11-18 09:07:37 --> Severity: Warning --> substr() expects parameter 3 to be integer, string given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 227
ERROR - 2019-11-18 09:07:57 --> Severity: Warning --> substr() expects parameter 3 to be integer, string given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 227
ERROR - 2019-11-18 09:07:58 --> Severity: Warning --> substr() expects parameter 3 to be integer, string given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 227
ERROR - 2019-11-18 09:12:25 --> 404 Page Not Found: Superadmin/code
ERROR - 2019-11-18 09:12:26 --> 404 Page Not Found: Superadmin/code
ERROR - 2019-11-18 09:12:27 --> 404 Page Not Found: Superadmin/random_strings
ERROR - 2019-11-18 09:12:28 --> 404 Page Not Found: Superadmin/random_strings
ERROR - 2019-11-18 09:12:29 --> 404 Page Not Found: Superadmin/random_strings
ERROR - 2019-11-18 10:48:56 --> Severity: Warning --> include(superadmin/alumni_gallery/index.php): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/index.php 35
ERROR - 2019-11-18 10:48:56 --> Severity: Warning --> include(): Failed opening 'superadmin/alumni_gallery/index.php' for inclusion (include_path='.:/usr/local/Cellar/php@7.2/7.2.13/share/php@7.2/pear') /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/index.php 35
ERROR - 2019-11-18 10:53:41 --> Severity: error --> Exception: Call to undefined method Alumni_model::event_update() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/addons/Alumni.php 79
ERROR - 2019-11-18 10:53:47 --> Severity: error --> Exception: Call to undefined method Alumni_model::event_update() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/addons/Alumni.php 79
ERROR - 2019-11-18 10:53:53 --> Severity: error --> Exception: Call to undefined method Alumni_model::event_update() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/addons/Alumni.php 79
ERROR - 2019-11-18 10:54:15 --> Severity: error --> Exception: Call to undefined method Alumni_model::event_update() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/addons/Alumni.php 79
ERROR - 2019-11-18 11:00:27 --> 404 Page Not Found: Superadmin/alumni_event
ERROR - 2019-11-18 11:07:09 --> 404 Page Not Found: Uploads/images
ERROR - 2019-11-18 11:07:09 --> 404 Page Not Found: Uploads/images
ERROR - 2019-11-18 11:07:13 --> 404 Page Not Found: Uploads/images
ERROR - 2019-11-18 11:10:28 --> 404 Page Not Found: Uploads/images
ERROR - 2019-11-18 11:11:23 --> 404 Page Not Found: Uploads/images
ERROR - 2019-11-18 11:11:24 --> 404 Page Not Found: Uploads/images
ERROR - 2019-11-18 11:19:26 --> Severity: Warning --> include(superadmin/alumni_gallery/index.php): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/index.php 35
ERROR - 2019-11-18 11:19:26 --> Severity: Warning --> include(): Failed opening 'superadmin/alumni_gallery/index.php' for inclusion (include_path='.:/usr/local/Cellar/php@7.2/7.2.13/share/php@7.2/pear') /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/index.php 35
ERROR - 2019-11-18 11:24:52 --> Severity: Notice --> Undefined variable: school_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/alumni_gallery/list.php 1
ERROR - 2019-11-18 11:43:26 --> Severity: Compile Error --> Cannot redeclare Alumni_model::event_update() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/addons/Alumni_model.php 205
ERROR - 2019-11-18 11:45:33 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:45:33 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:45:33 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:46:45 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:46:45 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:46:45 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:47:06 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:47:06 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:47:06 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:47:31 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:47:31 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:47:31 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:48:24 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:48:24 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:48:24 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:48:59 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:48:59 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:48:59 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:49:15 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:49:16 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:49:16 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:50:35 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:50:35 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:50:36 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:51:41 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:51:41 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:51:41 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:52:09 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:52:09 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:52:09 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:54:17 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:54:17 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:54:17 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:54:18 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:54:18 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:54:18 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:54:54 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:54:55 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:54:55 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:54:55 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:54:55 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:54:55 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:56:00 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:56:00 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:56:00 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:56:00 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:56:00 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:56:09 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:56:09 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:56:10 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:56:10 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:56:10 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:56:10 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:56:17 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:56:17 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:56:17 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:56:17 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:57:42 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:57:43 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:57:43 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:58:29 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:58:29 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 11:58:29 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:00:34 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:00:34 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:00:34 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:00:35 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:00:35 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:00:35 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:00:41 --> Severity: Warning --> unlink(uploads/images/alumni_events/): Operation not permitted /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/addons/Alumni_model.php 250
ERROR - 2019-11-18 12:00:49 --> Severity: Warning --> unlink(uploads/images/alumni_events/): Operation not permitted /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/addons/Alumni_model.php 250
ERROR - 2019-11-18 12:01:46 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:01:46 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:01:46 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:01:55 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:01:55 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:01:55 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:04:00 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:04:00 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:04:00 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:04:00 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:04:00 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:04:00 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:04:31 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:04:31 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:04:31 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:04:57 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:04:57 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:04:57 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:04:58 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:04:58 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:04:58 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:05:06 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:05:06 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:05:06 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:05:55 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:05:55 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:05:55 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:06:06 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:06:06 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:06:06 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:06:24 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:06:24 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:06:25 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:06:25 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:06:25 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:06:25 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:07:26 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:07:26 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:07:26 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:07:27 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:07:27 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:07:35 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:07:35 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:07:35 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:07:44 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:07:44 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:07:44 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:07:56 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:07:56 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:07:56 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:08:26 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:08:26 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:08:26 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:08:26 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:08:26 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:08:26 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:14:43 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:14:43 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:14:44 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:14:44 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:14:44 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:27:09 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:27:09 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:27:09 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:27:24 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:27:24 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:27:24 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:28:39 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:28:39 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:28:40 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:28:40 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:28:40 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:28:40 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:28:48 --> Query error: Unknown column 'galler_id' in 'field list' - Invalid query: INSERT INTO `alumni_gallery` (`galler_id`, `photo`) VALUES ('6', 'WVJ8agG4RrpuzlML6Xte.jpg')
ERROR - 2019-11-18 12:29:30 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:29:30 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:29:30 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:29:30 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:29:30 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:29:30 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:29:42 --> Query error: Unknown column 'gallery_id' in 'field list' - Invalid query: INSERT INTO `alumni_gallery` (`gallery_id`, `photo`) VALUES ('6', 'PqwSmXkyn6huolJ0VAQY.jpg')
ERROR - 2019-11-18 12:30:28 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:30:28 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:30:28 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:30:39 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:30:39 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:30:39 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:34:57 --> Query error: Unknown column 'galler_id' in 'where clause' - Invalid query: SELECT *
FROM `alumni_gallery_photos`
WHERE `galler_id` = '5'
ERROR - 2019-11-18 12:35:12 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:36:25 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:37:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/alumni_gallery/list.php 41
ERROR - 2019-11-18 12:37:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/alumni_gallery/list.php 41
ERROR - 2019-11-18 12:37:39 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:37:59 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:39:09 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:39:30 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:39:44 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:39:47 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:41:38 --> Severity: error --> Exception: syntax error, unexpected '' '' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/alumni_gallery/list.php 49
ERROR - 2019-11-18 12:42:03 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:42:13 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:42:20 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:42:27 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:42:34 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:43:54 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:43:54 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:44:02 --> 404 Page Not Found: addons/Alumni/assets
ERROR - 2019-11-18 12:47:58 --> Severity: Notice --> Undefined variable: galler /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/alumni_gallery/list.php 44
ERROR - 2019-11-18 12:47:58 --> Severity: Notice --> Undefined variable: galler /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/alumni_gallery/list.php 44
ERROR - 2019-11-18 12:47:58 --> Severity: Notice --> Undefined variable: galler /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/alumni_gallery/list.php 44
ERROR - 2019-11-18 12:47:58 --> Severity: Notice --> Undefined variable: galler /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/alumni_gallery/list.php 50
ERROR - 2019-11-18 12:55:32 --> Severity: Notice --> Undefined variable: gallery_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/alumni_gallery/photo_list.php 1
ERROR - 2019-11-18 12:55:32 --> Query error: Unknown column 'galler_id' in 'where clause' - Invalid query: SELECT *
FROM `alumni_gallery_photos`
WHERE `galler_id` IS NULL
ERROR - 2019-11-18 12:57:06 --> Severity: Notice --> Undefined variable: gallery_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/alumni_gallery/photo_list.php 1
ERROR - 2019-11-18 12:57:06 --> Query error: Unknown column 'galler_id' in 'where clause' - Invalid query: SELECT *
FROM `alumni_gallery_photos`
WHERE `galler_id` IS NULL
ERROR - 2019-11-18 12:57:23 --> Severity: Notice --> Undefined variable: gallery_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/alumni_gallery/photo_list.php 1
ERROR - 2019-11-18 12:57:23 --> Query error: Unknown column 'galler_id' in 'where clause' - Invalid query: SELECT *
FROM `alumni_gallery_photos`
WHERE `galler_id` IS NULL
ERROR - 2019-11-18 12:57:39 --> Severity: Notice --> Undefined variable: gallery_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/alumni_gallery/photo_list.php 1
ERROR - 2019-11-18 12:57:39 --> Query error: Unknown column 'galler_id' in 'where clause' - Invalid query: SELECT *
FROM `alumni_gallery_photos`
WHERE `galler_id` IS NULL
ERROR - 2019-11-18 12:58:03 --> Severity: Notice --> Undefined variable: gallery_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/alumni_gallery/photo_list.php 1
ERROR - 2019-11-18 12:58:03 --> Severity: Notice --> Undefined variable: gallery_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/alumni_gallery/photos.php 20
ERROR - 2019-11-18 12:58:03 --> Severity: Notice --> Undefined variable: gallery_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/alumni_gallery/photos.php 23
ERROR - 2019-11-18 12:58:13 --> Severity: Notice --> Undefined variable: gallery_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/alumni_gallery/photos.php 20
ERROR - 2019-11-18 12:58:13 --> Severity: Notice --> Undefined variable: gallery_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/alumni_gallery/photos.php 23
