<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-04 05:30:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-04 05:30:20 --> Unable to connect to the database
ERROR - 2019-12-04 05:30:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-04 05:30:20 --> Unable to connect to the database
ERROR - 2019-12-04 07:35:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-04 07:35:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-04 07:50:22 --> Severity: Notice --> Undefined index: class_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 138
ERROR - 2019-12-04 08:23:04 --> Severity: Notice --> Undefined index: auth_token /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/api/Admin.php 84
ERROR - 2019-12-04 09:01:33 --> Severity: Notice --> Undefined variable: enrol /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 180
ERROR - 2019-12-04 09:01:33 --> Severity: Notice --> Undefined variable: enrol /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 181
ERROR - 2019-12-04 09:01:33 --> Severity: Notice --> Undefined variable: enrol /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 180
ERROR - 2019-12-04 09:01:33 --> Severity: Notice --> Undefined variable: enrol /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 181
ERROR - 2019-12-04 09:01:33 --> Severity: Notice --> Undefined variable: enrol /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 180
ERROR - 2019-12-04 09:01:33 --> Severity: Notice --> Undefined variable: enrol /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 181
ERROR - 2019-12-04 09:01:33 --> Severity: Notice --> Undefined variable: enrol /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 180
ERROR - 2019-12-04 09:01:33 --> Severity: Notice --> Undefined variable: enrol /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 181
ERROR - 2019-12-04 09:01:33 --> Severity: Notice --> Undefined variable: enrol /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 180
ERROR - 2019-12-04 09:01:33 --> Severity: Notice --> Undefined variable: enrol /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 181
ERROR - 2019-12-04 09:01:33 --> Severity: Notice --> Undefined variable: enrol /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 180
ERROR - 2019-12-04 09:01:33 --> Severity: Notice --> Undefined variable: enrol /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 181
ERROR - 2019-12-04 09:01:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/core/Exceptions.php:271) /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/core/Common.php 570
ERROR - 2019-12-04 09:57:29 --> Severity: Notice --> Undefined index: class_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 138
ERROR - 2019-12-04 09:58:02 --> Severity: Notice --> Undefined index: class_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 138
ERROR - 2019-12-04 11:15:24 --> Severity: Warning --> Illegal string offset 'mark' /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 260
ERROR - 2019-12-04 11:15:24 --> Severity: error --> Exception: Cannot use string offset as an array /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 260
ERROR - 2019-12-04 11:16:18 --> Severity: Warning --> Illegal string offset 'mark' /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 260
ERROR - 2019-12-04 11:16:18 --> Severity: Warning --> Illegal string offset 'mark' /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 261
ERROR - 2019-12-04 11:16:18 --> Severity: Warning --> Cannot assign an empty string to a string offset /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 261
ERROR - 2019-12-04 11:16:18 --> Severity: Warning --> Illegal string offset 'mark' /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 260
ERROR - 2019-12-04 11:16:18 --> Severity: Warning --> Illegal string offset 'mark' /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 261
ERROR - 2019-12-04 11:16:18 --> Severity: Warning --> Cannot assign an empty string to a string offset /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 261
ERROR - 2019-12-04 11:16:18 --> Severity: Warning --> Illegal string offset 'mark' /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 260
ERROR - 2019-12-04 11:16:18 --> Severity: Warning --> Illegal string offset 'mark' /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 261
ERROR - 2019-12-04 11:16:18 --> Severity: Warning --> Cannot assign an empty string to a string offset /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 261
ERROR - 2019-12-04 11:16:18 --> Severity: Warning --> Illegal string offset 'mark' /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 260
ERROR - 2019-12-04 11:16:18 --> Severity: Warning --> Illegal string offset 'mark' /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 261
ERROR - 2019-12-04 11:16:18 --> Severity: Warning --> Cannot assign an empty string to a string offset /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 261
ERROR - 2019-12-04 11:16:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/core/Exceptions.php:271) /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/core/Common.php 570
ERROR - 2019-12-04 11:44:08 --> Severity: Notice --> Undefined variable: marks /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 260
ERROR - 2019-12-04 11:44:08 --> Severity: Warning --> Invalid argument supplied for foreach() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 260
ERROR - 2019-12-04 11:44:08 --> Severity: Notice --> Undefined variable: marks /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 260
ERROR - 2019-12-04 11:44:08 --> Severity: Warning --> Invalid argument supplied for foreach() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 260
ERROR - 2019-12-04 11:44:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/core/Exceptions.php:271) /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/core/Common.php 570
ERROR - 2019-12-04 12:04:02 --> Severity: Notice --> Undefined variable: marks /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 261
ERROR - 2019-12-04 12:04:02 --> Severity: Warning --> Invalid argument supplied for foreach() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 261
ERROR - 2019-12-04 12:04:02 --> Severity: Notice --> Undefined variable: marks /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 261
ERROR - 2019-12-04 12:04:02 --> Severity: Warning --> Invalid argument supplied for foreach() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/api/Admin_model.php 261
ERROR - 2019-12-04 12:04:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/core/Exceptions.php:271) /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/core/Common.php 570
ERROR - 2019-12-04 12:06:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-04 12:21:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `mark_upto` > `IS` `NULL`' at line 3 - Invalid query: SELECT *
FROM `grades`
WHERE `mark_from` < `IS` `NULL`
AND `mark_upto` > `IS` `NULL`
