<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-26 07:46:08 --> 404 Page Not Found: Uploads/image
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-26 07:46:08 --> 404 Page Not Found: Uploads/image
ERROR - 2019-11-26 07:46:08 --> 404 Page Not Found: Uploads/image
