<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-17 05:49:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 05:49:47 --> Unable to connect to the database
ERROR - 2019-12-17 06:50:35 --> 404 Page Not Found: /index
ERROR - 2019-12-17 10:07:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:07:27 --> 404 Page Not Found: Uploads/system
ERROR - 2019-12-17 10:07:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:07:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:07:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:07:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:07:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:07:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:07:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:07:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:07:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:07:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:07:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:07:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:07:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:07:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:07:29 --> 404 Page Not Found: Uploads/system
ERROR - 2019-12-17 10:09:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:06 --> 404 Page Not Found: Uploads/system
ERROR - 2019-12-17 10:09:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:40 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:40 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:40 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:40 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:40 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:40 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:40 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:40 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:40 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:09:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:10:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:40 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:40 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:13:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:17:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:17:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:17:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:17:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:17:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:17:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:17:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:17:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:17:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:17:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:17:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:17:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:17:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:17:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:17:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:18:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:18:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:18:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:18:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:18:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:18:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:18:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:18:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:18:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:18:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:18:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:18:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:18:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:18:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:18:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:21:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:46 --> Severity: Warning --> mysqli_connect(): (HY000/1049): Unknown database 'ekattor_fresh' /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Install.php 124
ERROR - 2019-12-17 10:22:46 --> Severity: Warning --> mysqli_close() expects parameter 1 to be mysqli, boolean given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Install.php 126
ERROR - 2019-12-17 10:22:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:48 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:48 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:48 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:22:48 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:23:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:23:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:23:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:23:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:23:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:23:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:23:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:23:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:23:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:23:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:23:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:23:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:23:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:23:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:23:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:43 --> Severity: Notice --> session_start(): A session had already been started - ignoring /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Install.php 99
ERROR - 2019-12-17 10:24:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:24:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:32:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:00 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:00 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:00 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:00 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:00 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:00 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:00 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:00 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:00 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:00 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:00 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:00 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:00 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:00 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:00 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:12 --> Severity: Notice --> session_start(): A session had already been started - ignoring /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Install.php 99
ERROR - 2019-12-17 10:33:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:22 --> Severity: Notice --> session_start(): A session had already been started - ignoring /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Install.php 160
ERROR - 2019-12-17 10:33:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:33:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:34:01 --> Severity: Notice --> session_start(): A session had already been started - ignoring /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Install.php 160
ERROR - 2019-12-17 10:34:01 --> Severity: Notice --> Undefined index: dbname /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Install.php 161
ERROR - 2019-12-17 10:34:01 --> Severity: Notice --> Undefined index: username /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Install.php 162
ERROR - 2019-12-17 10:34:01 --> Severity: Notice --> Undefined index: password /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Install.php 163
ERROR - 2019-12-17 10:34:01 --> Severity: Notice --> Undefined index: hostname /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Install.php 164
ERROR - 2019-12-17 10:34:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/core/Exceptions.php:271) /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/helpers/url_helper.php 561
ERROR - 2019-12-17 10:35:02 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:35:02 --> Unable to connect to the database
ERROR - 2019-12-17 10:35:08 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:35:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:35:08 --> Unable to connect to the database
ERROR - 2019-12-17 10:35:23 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:35:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:35:23 --> Unable to connect to the database
ERROR - 2019-12-17 10:35:37 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:35:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:35:37 --> Unable to connect to the database
ERROR - 2019-12-17 10:37:04 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:37:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:37:04 --> Unable to connect to the database
ERROR - 2019-12-17 10:37:06 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:37:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:37:06 --> Unable to connect to the database
ERROR - 2019-12-17 10:37:07 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:37:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:37:07 --> Unable to connect to the database
ERROR - 2019-12-17 10:37:07 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:37:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:37:07 --> Unable to connect to the database
ERROR - 2019-12-17 10:37:08 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:37:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:37:08 --> Unable to connect to the database
ERROR - 2019-12-17 10:37:08 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:37:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:37:08 --> Unable to connect to the database
ERROR - 2019-12-17 10:37:08 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:37:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:37:08 --> Unable to connect to the database
ERROR - 2019-12-17 10:37:08 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:37:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:37:08 --> Unable to connect to the database
ERROR - 2019-12-17 10:37:09 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:37:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:37:09 --> Unable to connect to the database
ERROR - 2019-12-17 10:37:09 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:37:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:37:09 --> Unable to connect to the database
ERROR - 2019-12-17 10:37:09 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:37:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:37:09 --> Unable to connect to the database
ERROR - 2019-12-17 10:37:33 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:37:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:37:33 --> Unable to connect to the database
ERROR - 2019-12-17 10:38:08 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:38:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:38:08 --> Unable to connect to the database
ERROR - 2019-12-17 10:38:08 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:38:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:38:08 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/libraries/Session/Session_driver.php 205
ERROR - 2019-12-17 10:38:08 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/libraries/Session/Session.php 143
ERROR - 2019-12-17 10:38:08 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:38:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:38:08 --> Unable to connect to the database
ERROR - 2019-12-17 10:38:08 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:38:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:38:08 --> Unable to connect to the database
ERROR - 2019-12-17 10:38:08 --> Query error: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known - Invalid query: SELECT *
FROM `settings`
WHERE `id` = 1
ERROR - 2019-12-17 10:38:08 --> Severity: error --> Exception: Call to a member function row_array() on boolean /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 15
ERROR - 2019-12-17 10:41:15 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:41:15 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:41:15 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:41:15 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:41:15 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:41:15 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:41:16 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:41:16 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:41:16 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:41:16 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:41:16 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:41:16 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:41:16 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:41:16 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:41:16 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:41:16 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:41:16 --> 404 Page Not Found: Uploads/system
ERROR - 2019-12-17 10:43:35 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:43:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:43:35 --> Unable to connect to the database
ERROR - 2019-12-17 10:43:35 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:43:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:43:35 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/libraries/Session/Session_driver.php 205
ERROR - 2019-12-17 10:43:35 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/libraries/Session/Session.php 143
ERROR - 2019-12-17 10:43:35 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:43:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:43:35 --> Unable to connect to the database
ERROR - 2019-12-17 10:43:35 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:43:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:43:35 --> Unable to connect to the database
ERROR - 2019-12-17 10:43:35 --> Query error: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known - Invalid query: SELECT *
FROM `settings`
WHERE `id` = 1
ERROR - 2019-12-17 10:43:35 --> Severity: error --> Exception: Call to a member function row_array() on boolean /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 15
ERROR - 2019-12-17 10:49:51 --> Severity: error --> Exception: Call to a member function userdata() on null /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 161
ERROR - 2019-12-17 10:50:25 --> Severity: Notice --> Undefined property: Install::$session /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 161
ERROR - 2019-12-17 10:50:25 --> Severity: error --> Exception: Call to a member function userdata() on null /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 161
ERROR - 2019-12-17 10:51:47 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:51:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:51:47 --> Unable to connect to the database
ERROR - 2019-12-17 10:52:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:52:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:52:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:52:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:52:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:52:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:52:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:52:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:52:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:52:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:52:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:52:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:52:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:52:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:52:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:52:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:52:46 --> Severity: Notice --> Undefined property: Install::$session /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 161
ERROR - 2019-12-17 10:52:46 --> Severity: error --> Exception: Call to a member function userdata() on null /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 161
ERROR - 2019-12-17 10:53:31 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:53:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-17 10:53:31 --> Unable to connect to the database
ERROR - 2019-12-17 10:53:59 --> Severity: Notice --> Undefined property: Install::$session /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 161
ERROR - 2019-12-17 10:53:59 --> Severity: error --> Exception: Call to a member function userdata() on null /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 161
ERROR - 2019-12-17 10:55:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:55:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:55:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:55:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:55:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:55:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:55:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:55:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:55:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:55:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:55:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:55:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:55:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:55:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:55:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 10:55:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:08:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:08:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:08:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:08:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:08:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:08:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:08:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:08:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:08:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:08:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:08:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:08:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:08:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:08:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:08:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:08:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:52 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:52 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:10:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:11:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:17:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:17:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:17:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:17:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:17:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:17:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:17:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:17:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:17:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:17:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:17:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:17:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:17:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:17:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:17:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:20:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:20:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:20:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:20:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:20:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:20:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:20:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:20:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:20:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:20:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:20:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:20:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:20:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:20:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:20:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:20:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:15 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:15 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:15 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:15 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:15 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:15 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:15 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:15 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:15 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:15 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:15 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:15 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:15 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:21:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:22:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:23:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:56 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:56 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:56 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:56 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:56 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:56 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:56 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:56 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:56 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:56 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:56 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:56 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:56 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:56 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:24:56 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:50:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:50:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:50:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:50:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:50:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:50:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:50:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:50:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:50:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:50:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:50:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:50:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:50:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:50:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:50:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:50:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:52:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:52:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:52:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:52:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:52:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:52:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:52:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:52:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:52:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:52:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:52:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:52:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:52:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:52:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:52:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-17 11:58:39 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/student/profile.php 9
ERROR - 2019-12-17 11:58:39 --> Severity: error --> Exception: Call to a member function get_user_image() on null /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/student/profile.php 9
ERROR - 2019-12-17 11:58:57 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/student/profile.php 9
ERROR - 2019-12-17 11:58:57 --> Severity: error --> Exception: Call to a member function get_user_image() on null /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/student/profile.php 9
ERROR - 2019-12-17 12:00:40 --> Severity: Notice --> Undefined property: Superadmin::$session /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 161
ERROR - 2019-12-17 12:00:40 --> Severity: error --> Exception: Call to a member function userdata() on null /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 161
ERROR - 2019-12-17 12:00:47 --> Severity: Notice --> Undefined property: Superadmin::$session /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 161
ERROR - 2019-12-17 12:00:47 --> Severity: error --> Exception: Call to a member function userdata() on null /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 161
ERROR - 2019-12-17 12:00:49 --> Severity: Notice --> Undefined property: Superadmin::$session /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 161
ERROR - 2019-12-17 12:00:49 --> Severity: error --> Exception: Call to a member function userdata() on null /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 161
ERROR - 2019-12-17 12:01:09 --> Severity: Notice --> Undefined property: Superadmin::$session /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 161
ERROR - 2019-12-17 12:01:09 --> Severity: error --> Exception: Call to a member function userdata() on null /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 161
ERROR - 2019-12-17 12:01:10 --> Severity: Notice --> Undefined property: Superadmin::$session /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 161
ERROR - 2019-12-17 12:01:10 --> Severity: error --> Exception: Call to a member function userdata() on null /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 161
ERROR - 2019-12-17 12:01:50 --> Severity: Notice --> Undefined property: CI_Loader::$user_model /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/student/profile.php 9
ERROR - 2019-12-17 12:01:50 --> Severity: error --> Exception: Call to a member function get_user_image() on null /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/student/profile.php 9
ERROR - 2019-12-17 12:02:02 --> Severity: Notice --> Undefined property: CI_Loader::$crud_model /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/admin/create.php 32
ERROR - 2019-12-17 12:02:02 --> Severity: error --> Exception: Call to a member function get_schools() on null /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/admin/create.php 32
