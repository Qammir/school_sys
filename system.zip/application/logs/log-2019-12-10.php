<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-10 06:16:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-10 06:16:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-10 06:16:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-10 08:56:17 --> 404 Page Not Found: Assets/backend
