<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-24 05:54:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-24 05:54:53 --> Unable to connect to the database
