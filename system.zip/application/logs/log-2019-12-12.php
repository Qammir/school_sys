<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-12 05:42:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-12 05:42:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-12 07:17:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-12 07:17:38 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-12 09:55:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-12 10:08:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-12 10:31:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-12 10:39:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-12 10:39:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-12 10:43:38 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-12 10:43:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-12 10:45:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-12 10:45:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-12 10:45:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-12 10:46:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-12-12 10:46:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-12-12 10:49:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-12-12 10:50:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-12 10:50:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-12 10:50:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-12-12 10:56:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-12-12 10:56:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-12 10:56:54 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-12 11:01:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-12-12 11:01:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-12-12 11:01:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-12-12 11:02:25 --> Severity: Notice --> Undefined property: CI_Loader::$system_model /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/navigation.php 2
ERROR - 2019-12-12 11:02:25 --> Severity: error --> Exception: Call to a member function get_logo_dark() on null /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/navigation.php 2
ERROR - 2019-12-12 11:02:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-12-12 11:02:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-12-12 11:03:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-12-12 11:03:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-12-12 11:10:23 --> Severity: Notice --> Undefined variable: school_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/metas.php 2
ERROR - 2019-12-12 11:10:29 --> Severity: Notice --> Undefined variable: school_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/metas.php 2
ERROR - 2019-12-12 11:10:37 --> Severity: Notice --> Undefined variable: school_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/metas.php 2
ERROR - 2019-12-12 11:10:45 --> Severity: Notice --> Undefined variable: school_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/metas.php 2
ERROR - 2019-12-12 11:10:47 --> Severity: Notice --> Undefined variable: school_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/metas.php 2
ERROR - 2019-12-12 11:10:54 --> Severity: Notice --> Undefined variable: school_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/metas.php 2
ERROR - 2019-12-12 11:32:38 --> Query error: Unknown column 'school_id' in 'where clause' - Invalid query: SELECT *
FROM `sessions`
WHERE `school_id` = '1'
ERROR - 2019-12-12 11:33:27 --> Query error: Unknown column 'school_id' in 'where clause' - Invalid query: SELECT *
FROM `sessions`
WHERE `school_id` = '1'
ERROR - 2019-12-12 11:33:45 --> Query error: Unknown column 'school_id' in 'where clause' - Invalid query: SELECT *
FROM `sessions`
WHERE `school_id` = '1'
ERROR - 2019-12-12 11:33:53 --> Query error: Unknown column 'school_id' in 'where clause' - Invalid query: SELECT *
FROM `sessions`
WHERE `school_id` = '1'
ERROR - 2019-12-12 11:47:42 --> Query error: Unknown column 'school_id' in 'where clause' - Invalid query: UPDATE `sessions` SET `status` = 0
WHERE `status` = 1
AND `school_id` = '1'
ERROR - 2019-12-12 11:48:12 --> Query error: Unknown column 'school_id' in 'where clause' - Invalid query: UPDATE `sessions` SET `status` = 0
WHERE `status` = 1
AND `school_id` = '1'
ERROR - 2019-12-12 11:48:24 --> Query error: Unknown column 'school_id' in 'where clause' - Invalid query: UPDATE `sessions` SET `status` = 0
WHERE `status` = 1
AND `school_id` = '1'
ERROR - 2019-12-12 12:19:51 --> Query error: Unknown column 'mark_to' in 'where clause' - Invalid query: SELECT *
FROM `grades`
WHERE `mark_from` <= '0'
AND `mark_to` >= '0'
ERROR - 2019-12-12 12:19:52 --> Query error: Unknown column 'mark_to' in 'where clause' - Invalid query: SELECT *
FROM `grades`
WHERE `mark_from` <= '0'
AND `mark_to` >= '0'
ERROR - 2019-12-12 12:20:04 --> Query error: Unknown column 'mark_to' in 'where clause' - Invalid query: SELECT *
FROM `grades`
WHERE `mark_from` <= '0'
AND `mark_to` >= '0'
ERROR - 2019-12-12 12:20:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `mark_upto` > `IS` `NULL`' at line 3 - Invalid query: SELECT *
FROM `grades`
WHERE `mark_from` < `IS` `NULL`
AND `mark_upto` > `IS` `NULL`
ERROR - 2019-12-12 12:20:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `mark_upto` > `IS` `NULL`' at line 3 - Invalid query: SELECT *
FROM `grades`
WHERE `mark_from` < `IS` `NULL`
AND `mark_upto` > `IS` `NULL`
ERROR - 2019-12-12 12:21:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `mark_upto` > `IS` `NULL`' at line 3 - Invalid query: SELECT *
FROM `grades`
WHERE `mark_from` < `IS` `NULL`
AND `mark_upto` > `IS` `NULL`
ERROR - 2019-12-12 12:29:50 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 31
ERROR - 2019-12-12 12:29:50 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 32
ERROR - 2019-12-12 12:29:50 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 33
ERROR - 2019-12-12 12:29:50 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 42
ERROR - 2019-12-12 12:29:50 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 43
ERROR - 2019-12-12 12:29:50 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 44
ERROR - 2019-12-12 12:29:50 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 45
ERROR - 2019-12-12 12:29:50 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 46
ERROR - 2019-12-12 12:29:50 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 47
ERROR - 2019-12-12 12:29:50 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 48
ERROR - 2019-12-12 12:29:50 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 49
ERROR - 2019-12-12 12:40:07 --> 404 Page Not Found: Admin/get_grade
ERROR - 2019-12-12 12:53:15 --> Query error: Unknown column 'twilio_sid' in 'field list' - Invalid query: INSERT INTO `sms_settings` (`active_sms_service`, `twilio_sid`, `twilio_token`, `twilio_from`, `msg91_authentication_key`, `msg91_sender_id`, `msg91_route`, `msg91_country_code`) VALUES ('', '', '', '', '', '', '', '')
ERROR - 2019-12-12 12:53:21 --> Severity: Notice --> Undefined index: addon_zip /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Addon_model.php 33
ERROR - 2019-12-12 12:55:39 --> Query error: Unknown column 'twilio_sid' in 'field list' - Invalid query: INSERT INTO `sms_settings` (`active_sms_service`, `twilio_sid`, `twilio_token`, `twilio_from`, `msg91_authentication_key`, `msg91_sender_id`, `msg91_route`, `msg91_country_code`) VALUES ('', '', '', '', '', '', '', '')
ERROR - 2019-12-12 13:07:58 --> Severity: error --> Exception: [HTTP 400] Unable to create record: The number  is unverified. Trial accounts cannot send messages to unverified numbers; verify  at twilio.com/user/account/phone-numbers/verified, or purchase a Twilio number to send messages to unverified numbers. /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/third_party/twilio/src/Twilio/Version.php 85
ERROR - 2019-12-12 13:08:31 --> Severity: error --> Exception: [HTTP 400] Unable to create record: The number  is unverified. Trial accounts cannot send messages to unverified numbers; verify  at twilio.com/user/account/phone-numbers/verified, or purchase a Twilio number to send messages to unverified numbers. /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/third_party/twilio/src/Twilio/Version.php 85
ERROR - 2019-12-12 13:09:50 --> Severity: error --> Exception: [HTTP 400] Unable to create record: The number  is unverified. Trial accounts cannot send messages to unverified numbers; verify  at twilio.com/user/account/phone-numbers/verified, or purchase a Twilio number to send messages to unverified numbers. /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/third_party/twilio/src/Twilio/Version.php 85
ERROR - 2019-12-12 13:21:04 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 31
ERROR - 2019-12-12 13:21:04 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 32
ERROR - 2019-12-12 13:21:04 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 33
ERROR - 2019-12-12 13:21:04 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 42
ERROR - 2019-12-12 13:21:04 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 43
ERROR - 2019-12-12 13:21:04 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 44
ERROR - 2019-12-12 13:21:04 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 45
ERROR - 2019-12-12 13:21:04 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 46
ERROR - 2019-12-12 13:21:04 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 47
ERROR - 2019-12-12 13:21:04 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 48
ERROR - 2019-12-12 13:21:04 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 49
ERROR - 2019-12-12 13:21:18 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 31
ERROR - 2019-12-12 13:21:18 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 32
ERROR - 2019-12-12 13:21:18 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 33
ERROR - 2019-12-12 13:21:18 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 42
ERROR - 2019-12-12 13:21:18 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 43
ERROR - 2019-12-12 13:21:18 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 44
ERROR - 2019-12-12 13:21:18 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 45
ERROR - 2019-12-12 13:21:18 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 46
ERROR - 2019-12-12 13:21:18 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 47
ERROR - 2019-12-12 13:21:18 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 48
ERROR - 2019-12-12 13:21:18 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/accountant/create.php 49
ERROR - 2019-12-12 13:35:29 --> Severity: Warning --> fopen(uploads/csv_file/student.generate (2).csv): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 680
ERROR - 2019-12-12 13:35:29 --> Severity: Notice --> Undefined variable: duplication_counter /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 722
ERROR - 2019-12-12 13:37:01 --> Severity: Warning --> fopen(uploads/csv_file/student.generate (2).csv): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 680
ERROR - 2019-12-12 13:37:01 --> Severity: Notice --> Undefined variable: duplication_counter /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 722
ERROR - 2019-12-12 13:37:09 --> Severity: Warning --> fopen(uploads/csv_file/student.generate (2).csv): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 680
ERROR - 2019-12-12 13:37:09 --> Severity: Notice --> Undefined variable: duplication_counter /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 722
ERROR - 2019-12-12 13:37:10 --> Severity: Warning --> fopen(uploads/csv_file/student.generate (2).csv): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 680
ERROR - 2019-12-12 13:37:10 --> Severity: Notice --> Undefined variable: duplication_counter /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 722
ERROR - 2019-12-12 13:37:10 --> Severity: Warning --> fopen(uploads/csv_file/student.generate (2).csv): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 680
ERROR - 2019-12-12 13:37:10 --> Severity: Notice --> Undefined variable: duplication_counter /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 722
ERROR - 2019-12-12 13:37:10 --> Severity: Warning --> fopen(uploads/csv_file/student.generate (2).csv): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 680
ERROR - 2019-12-12 13:37:10 --> Severity: Notice --> Undefined variable: duplication_counter /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 722
ERROR - 2019-12-12 13:37:11 --> Severity: Warning --> fopen(uploads/csv_file/student.generate (2).csv): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 680
ERROR - 2019-12-12 13:37:11 --> Severity: Notice --> Undefined variable: duplication_counter /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 722
ERROR - 2019-12-12 13:37:11 --> Severity: Warning --> fopen(uploads/csv_file/student.generate (2).csv): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 680
ERROR - 2019-12-12 13:37:11 --> Severity: Notice --> Undefined variable: duplication_counter /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 722
ERROR - 2019-12-12 13:37:11 --> Severity: Warning --> fopen(uploads/csv_file/student.generate (2).csv): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 680
ERROR - 2019-12-12 13:37:11 --> Severity: Notice --> Undefined variable: duplication_counter /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 722
ERROR - 2019-12-12 13:37:11 --> Severity: Warning --> fopen(uploads/csv_file/student.generate (2).csv): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 680
ERROR - 2019-12-12 13:37:11 --> Severity: Notice --> Undefined variable: duplication_counter /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 722
ERROR - 2019-12-12 13:37:11 --> Severity: Warning --> fopen(uploads/csv_file/student.generate (2).csv): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 680
ERROR - 2019-12-12 13:37:11 --> Severity: Notice --> Undefined variable: duplication_counter /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 722
ERROR - 2019-12-12 13:37:17 --> Severity: Warning --> fopen(uploads/csv_file/student.generate (2).csv): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 680
ERROR - 2019-12-12 13:37:17 --> Severity: Notice --> Undefined variable: duplication_counter /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 722
ERROR - 2019-12-12 13:37:24 --> Severity: Warning --> fopen(uploads/csv_file/student.generate (2).csv): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 680
ERROR - 2019-12-12 13:37:24 --> Severity: Notice --> Undefined variable: duplication_counter /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/User_model.php 722
