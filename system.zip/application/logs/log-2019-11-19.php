<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-19 05:20:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-11-19 05:20:18 --> Unable to connect to the database
ERROR - 2019-11-19 05:21:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 05:21:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 05:21:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 06:58:50 --> Severity: Warning --> include(superadmin/alumni_gallery_photo/index.php): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/index.php 35
ERROR - 2019-11-19 06:58:50 --> Severity: Warning --> include(): Failed opening 'superadmin/alumni_gallery_photo/index.php' for inclusion (include_path='.:/usr/local/Cellar/php@7.2/7.2.13/share/php@7.2/pear') /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/index.php 35
ERROR - 2019-11-19 06:59:30 --> Severity: Warning --> include(photo_list.php): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/alumni_gallery_photo/index.php 18
ERROR - 2019-11-19 06:59:30 --> Severity: Warning --> include(): Failed opening 'photo_list.php' for inclusion (include_path='.:/usr/local/Cellar/php@7.2/7.2.13/share/php@7.2/pear') /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/alumni_gallery_photo/index.php 18
ERROR - 2019-11-19 06:59:37 --> Severity: Warning --> include(photo_list.php): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/alumni_gallery_photo/index.php 18
ERROR - 2019-11-19 06:59:37 --> Severity: Warning --> include(): Failed opening 'photo_list.php' for inclusion (include_path='.:/usr/local/Cellar/php@7.2/7.2.13/share/php@7.2/pear') /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/alumni_gallery_photo/index.php 18
ERROR - 2019-11-19 06:59:45 --> Severity: Warning --> include(photo_list.php): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/alumni_gallery_photo/index.php 18
ERROR - 2019-11-19 06:59:45 --> Severity: Warning --> include(): Failed opening 'photo_list.php' for inclusion (include_path='.:/usr/local/Cellar/php@7.2/7.2.13/share/php@7.2/pear') /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/alumni_gallery_photo/index.php 18
ERROR - 2019-11-19 07:38:55 --> 404 Page Not Found: addons/Alumni/gallery
ERROR - 2019-11-19 07:39:30 --> 404 Page Not Found: addons/Alumni/index
ERROR - 2019-11-19 07:39:36 --> 404 Page Not Found: addons/Alumni/gallery
ERROR - 2019-11-19 07:39:40 --> 404 Page Not Found: addons//index
ERROR - 2019-11-19 07:40:01 --> 404 Page Not Found: addons//index
ERROR - 2019-11-19 07:46:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 07:46:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 07:52:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 07:52:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 09:28:08 --> Severity: error --> Exception: syntax error, unexpected 'protected' (T_PROTECTED) /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Home.php 15
ERROR - 2019-11-19 09:28:24 --> Severity: Notice --> Undefined variable: school_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/metas.php 2
ERROR - 2019-11-19 09:28:24 --> Query error: Table 'ekattor_7.frontend_general_settings' doesn't exist - Invalid query: SELECT *
FROM `frontend_general_settings`
WHERE `type` = 'header_logo'
ERROR - 2019-11-19 09:30:00 --> Severity: Notice --> Undefined variable: school_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/metas.php 2
ERROR - 2019-11-19 09:30:00 --> Query error: Table 'ekattor_7.frontend_general_settings' doesn't exist - Invalid query: SELECT *
FROM `frontend_general_settings`
WHERE `type` = 'header_logo'
ERROR - 2019-11-19 09:44:58 --> Severity: Notice --> Undefined variable: school_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/metas.php 2
ERROR - 2019-11-19 09:44:58 --> Query error: Table 'ekattor_7.frontend_general_settings' doesn't exist - Invalid query: SELECT *
FROM `frontend_general_settings`
WHERE `type` = 'header_logo'
ERROR - 2019-11-19 09:46:50 --> Severity: Notice --> Undefined variable: school_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/metas.php 2
ERROR - 2019-11-19 09:46:50 --> Query error: Table 'ekattor_7.frontend_general_settings' doesn't exist - Invalid query: SELECT *
FROM `frontend_general_settings`
WHERE `type` = 'header_logo'
ERROR - 2019-11-19 09:48:37 --> Severity: Notice --> Undefined variable: school_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/metas.php 2
ERROR - 2019-11-19 09:48:37 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'header_logo'
ERROR - 2019-11-19 09:50:26 --> Severity: Notice --> Undefined variable: school_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/metas.php 2
ERROR - 2019-11-19 09:50:26 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'header_logo'
ERROR - 2019-11-19 09:50:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 09:50:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 09:50:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 09:50:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 09:50:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 09:50:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 09:50:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 09:50:27 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 09:51:25 --> Severity: Notice --> Undefined variable: school_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/metas.php 2
ERROR - 2019-11-19 09:51:25 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `settings`
WHERE `type` = 'system_name'
ERROR - 2019-11-19 09:51:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 09:51:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 09:51:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 09:51:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 09:51:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 09:51:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 09:51:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 09:51:39 --> Severity: Notice --> Undefined variable: school_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/metas.php 2
ERROR - 2019-11-19 09:51:39 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'header_logo'
ERROR - 2019-11-19 09:51:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 09:51:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 09:51:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 09:51:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 09:51:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 09:51:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 09:51:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 09:55:45 --> Severity: Notice --> Undefined variable: school_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/metas.php 2
ERROR - 2019-11-19 09:55:45 --> Query error: Table 'ekattor_7.teacher' doesn't exist - Invalid query: SELECT *
FROM `teacher`
WHERE `show_on_website` = 1
ERROR - 2019-11-19 09:55:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 09:55:45 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 09:55:46 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 09:55:46 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 09:55:46 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 09:55:58 --> Severity: Notice --> Undefined variable: school_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/metas.php 2
ERROR - 2019-11-19 09:55:58 --> Query error: Table 'ekattor_7.teacher' doesn't exist - Invalid query: SELECT *
FROM `teacher`
WHERE `show_on_website` = 1
ERROR - 2019-11-19 09:56:27 --> Query error: Table 'ekattor_7.teacher' doesn't exist - Invalid query: SELECT *
FROM `teacher`
WHERE `show_on_website` = 1
ERROR - 2019-11-19 09:56:45 --> Query error: Table 'ekattor_7.teacher' doesn't exist - Invalid query: SELECT *
FROM `teacher`
WHERE `show_on_website` = 1
ERROR - 2019-11-19 09:56:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 09:56:45 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 09:56:45 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 09:56:45 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 09:56:45 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 09:57:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 09:57:08 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 09:57:21 --> Query error: Table 'ekattor_7.teacher' doesn't exist - Invalid query: SELECT *
FROM `teacher`
WHERE `show_on_website` = 1
ERROR - 2019-11-19 09:57:21 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 09:57:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 09:57:21 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 09:57:21 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 09:57:21 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:01:37 --> Query error: Table 'ekattor_7.teacher' doesn't exist - Invalid query: SELECT *
FROM `teacher`
WHERE `show_on_website` = 1
ERROR - 2019-11-19 10:01:38 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:01:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 10:01:38 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:01:38 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:01:38 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:03:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 10:03:31 --> 404 Page Not Found: Uploads/system
ERROR - 2019-11-19 10:03:31 --> 404 Page Not Found: Uploads/system
ERROR - 2019-11-19 10:03:32 --> 404 Page Not Found: Uploads/system
ERROR - 2019-11-19 10:03:35 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 10:03:35 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 10:04:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 10:04:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 10:04:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 10:04:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 10:04:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 10:04:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 10:04:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 10:04:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 10:04:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 10:04:30 --> Query error: Table 'ekattor_7.teacher' doesn't exist - Invalid query: SELECT *
FROM `teacher`
WHERE `show_on_website` = 1
ERROR - 2019-11-19 10:04:31 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:04:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 10:04:31 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:04:31 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:04:31 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:16:51 --> Query error: Table 'ekattor_7.teacher' doesn't exist - Invalid query: SELECT *
FROM `teacher`
WHERE `show_on_website` = 1
ERROR - 2019-11-19 10:16:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 10:16:52 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:16:52 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:16:52 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:16:52 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:18:09 --> Query error: Table 'ekattor_7.teacher' doesn't exist - Invalid query: SELECT *
FROM `teacher`
WHERE `show_on_website` = 1
ERROR - 2019-11-19 10:18:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 10:18:09 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:18:10 --> 404 Page Not Found: Uploads/system
ERROR - 2019-11-19 10:18:10 --> 404 Page Not Found: Uploads/system
ERROR - 2019-11-19 10:18:19 --> Query error: Table 'ekattor_7.teacher' doesn't exist - Invalid query: SELECT *
FROM `teacher`
WHERE `show_on_website` = 1
ERROR - 2019-11-19 10:19:13 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'footer_logo'
ERROR - 2019-11-19 10:19:16 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'footer_logo'
ERROR - 2019-11-19 10:19:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 10:19:16 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:19:16 --> 404 Page Not Found: Uploads/admin_image
ERROR - 2019-11-19 10:19:16 --> 404 Page Not Found: Uploads/system
ERROR - 2019-11-19 10:19:16 --> 404 Page Not Found: Uploads/system
ERROR - 2019-11-19 10:19:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 10:19:31 --> Query error: Table 'ekattor_7.teacher' doesn't exist - Invalid query: SELECT *
FROM `teacher`
WHERE `show_on_website` = 1
ERROR - 2019-11-19 10:19:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 10:19:31 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:19:31 --> 404 Page Not Found: Uploads/system
ERROR - 2019-11-19 10:19:31 --> 404 Page Not Found: Uploads/system
ERROR - 2019-11-19 10:20:51 --> Query error: Table 'ekattor_7.teacher' doesn't exist - Invalid query: SELECT *
FROM `teacher`
WHERE `show_on_website` = 1
ERROR - 2019-11-19 10:20:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 10:20:51 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:20:51 --> 404 Page Not Found: Uploads/system
ERROR - 2019-11-19 10:20:51 --> 404 Page Not Found: Uploads/system
ERROR - 2019-11-19 10:21:22 --> Query error: Table 'ekattor_7.teacher' doesn't exist - Invalid query: SELECT *
FROM `teacher`
WHERE `show_on_website` = 1
ERROR - 2019-11-19 10:21:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 10:21:22 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:22:25 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:23:08 --> Query error: Table 'ekattor_7.teacher' doesn't exist - Invalid query: SELECT *
FROM `teacher`
WHERE `show_on_website` = 1
ERROR - 2019-11-19 10:23:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 10:23:48 --> Query error: Table 'ekattor_7.teacher' doesn't exist - Invalid query: SELECT *
FROM `teacher`
WHERE `show_on_website` = 1
ERROR - 2019-11-19 10:23:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 10:26:17 --> Query error: Table 'ekattor_7.teacher' doesn't exist - Invalid query: SELECT *
FROM `teacher`
WHERE `show_on_website` = 1
ERROR - 2019-11-19 10:26:20 --> Query error: Table 'ekattor_7.teacher' doesn't exist - Invalid query: SELECT *
FROM `teacher`
WHERE `show_on_website` = 1
ERROR - 2019-11-19 10:31:06 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'homepage_note_title'
ERROR - 2019-11-19 10:31:06 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:31:06 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:31:06 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:31:14 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'homepage_note_title'
ERROR - 2019-11-19 10:31:14 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:31:14 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:31:14 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:31:43 --> Query error: Table 'ekattor_7.teacher' doesn't exist - Invalid query: SELECT *
FROM `teacher`
WHERE `show_on_website` = 1
ERROR - 2019-11-19 10:31:43 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:31:43 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:31:43 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:33:22 --> Query error: Table 'ekattor_7.teacher' doesn't exist - Invalid query: SELECT *
FROM `teacher`
WHERE `show_on_website` = 1
ERROR - 2019-11-19 10:34:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 10:36:01 --> Query error: Table 'ekattor_7.teacher' doesn't exist - Invalid query: SELECT *
FROM `teacher`
WHERE `show_on_website` = 1
ERROR - 2019-11-19 10:36:08 --> 404 Page Not Found: Home/about
ERROR - 2019-11-19 10:36:10 --> Query error: Table 'ekattor_7.teacher' doesn't exist - Invalid query: SELECT *
FROM `teacher`
WHERE `show_on_website` = 1
ERROR - 2019-11-19 10:37:16 --> Query error: Table 'ekattor_7.teacher' doesn't exist - Invalid query: SELECT *
FROM `teacher`
WHERE `show_on_website` = 1
ERROR - 2019-11-19 10:38:09 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'footer_logo'
ERROR - 2019-11-19 10:38:10 --> 404 Page Not Found: Uploads/admin_image
ERROR - 2019-11-19 10:38:46 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'footer_logo'
ERROR - 2019-11-19 10:45:22 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'footer_logo'
ERROR - 2019-11-19 10:45:27 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'footer_logo'
ERROR - 2019-11-19 10:51:39 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'social_links'
ERROR - 2019-11-19 10:56:19 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'phone'
ERROR - 2019-11-19 10:57:00 --> Severity: Notice --> Undefined index: email /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-11-19 10:57:00 --> Severity: Notice --> Undefined index: email /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-11-19 10:57:00 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:57:36 --> Severity: Notice --> Undefined index: email /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-11-19 10:57:37 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:57:55 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:58:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 10:58:43 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-19 10:58:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 10:59:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 10:59:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:03:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:04:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:06:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:06:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:06:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:06:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:07:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:07:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:07:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:08:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:08:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:09:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:24:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:27:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:28:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 11:28:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 11:28:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:29:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:29:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:30:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:43:41 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 11:43:41 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 11:43:41 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 11:43:41 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 11:43:41 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 11:43:41 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 11:43:41 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 11:43:41 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 11:43:41 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 11:43:41 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 11:43:41 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 11:43:41 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 11:43:41 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 11:43:41 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 11:43:48 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 11:43:48 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 130
ERROR - 2019-11-19 11:43:48 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 133
ERROR - 2019-11-19 11:43:48 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 139
ERROR - 2019-11-19 11:43:48 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 145
ERROR - 2019-11-19 11:43:48 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 151
ERROR - 2019-11-19 11:43:48 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 160
ERROR - 2019-11-19 11:43:48 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 11:43:48 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 130
ERROR - 2019-11-19 11:43:48 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 133
ERROR - 2019-11-19 11:43:48 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 139
ERROR - 2019-11-19 11:43:48 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 145
ERROR - 2019-11-19 11:43:48 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 151
ERROR - 2019-11-19 11:43:48 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 160
ERROR - 2019-11-19 11:44:43 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 11:44:43 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 11:45:26 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 11:45:26 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 130
ERROR - 2019-11-19 11:45:26 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 133
ERROR - 2019-11-19 11:45:26 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 139
ERROR - 2019-11-19 11:45:26 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 145
ERROR - 2019-11-19 11:45:26 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 151
ERROR - 2019-11-19 11:45:26 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 160
ERROR - 2019-11-19 11:45:26 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 11:45:26 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 130
ERROR - 2019-11-19 11:45:26 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 133
ERROR - 2019-11-19 11:45:26 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 139
ERROR - 2019-11-19 11:45:26 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 145
ERROR - 2019-11-19 11:45:26 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 151
ERROR - 2019-11-19 11:45:26 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 160
ERROR - 2019-11-19 11:49:32 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 11:49:32 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 130
ERROR - 2019-11-19 11:49:32 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 133
ERROR - 2019-11-19 11:49:32 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 139
ERROR - 2019-11-19 11:49:32 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 145
ERROR - 2019-11-19 11:49:32 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 151
ERROR - 2019-11-19 11:49:32 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 160
ERROR - 2019-11-19 11:49:32 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 11:49:32 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 130
ERROR - 2019-11-19 11:49:32 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 133
ERROR - 2019-11-19 11:49:32 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 139
ERROR - 2019-11-19 11:49:32 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 145
ERROR - 2019-11-19 11:49:32 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 151
ERROR - 2019-11-19 11:49:32 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 160
ERROR - 2019-11-19 11:49:32 --> Severity: error --> Exception: Cannot use object of type mysqli as array /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/footer.php 67
ERROR - 2019-11-19 11:49:48 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 11:49:48 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 130
ERROR - 2019-11-19 11:49:48 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 133
ERROR - 2019-11-19 11:49:48 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 139
ERROR - 2019-11-19 11:49:48 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 145
ERROR - 2019-11-19 11:49:48 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 151
ERROR - 2019-11-19 11:49:48 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 160
ERROR - 2019-11-19 11:49:48 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 11:49:48 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 130
ERROR - 2019-11-19 11:49:48 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 133
ERROR - 2019-11-19 11:49:48 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 139
ERROR - 2019-11-19 11:49:48 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 145
ERROR - 2019-11-19 11:49:48 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 151
ERROR - 2019-11-19 11:49:48 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 160
ERROR - 2019-11-19 11:51:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:51:04 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 11:51:04 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 130
ERROR - 2019-11-19 11:51:04 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 133
ERROR - 2019-11-19 11:51:04 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 139
ERROR - 2019-11-19 11:51:04 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 145
ERROR - 2019-11-19 11:51:04 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 151
ERROR - 2019-11-19 11:51:04 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 160
ERROR - 2019-11-19 11:51:04 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 11:51:04 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 130
ERROR - 2019-11-19 11:51:04 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 133
ERROR - 2019-11-19 11:51:04 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 139
ERROR - 2019-11-19 11:51:04 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 145
ERROR - 2019-11-19 11:51:04 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 151
ERROR - 2019-11-19 11:51:04 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 160
ERROR - 2019-11-19 11:51:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:51:26 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 11:51:26 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 130
ERROR - 2019-11-19 11:51:26 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 133
ERROR - 2019-11-19 11:51:26 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 139
ERROR - 2019-11-19 11:51:26 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 145
ERROR - 2019-11-19 11:51:26 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 151
ERROR - 2019-11-19 11:51:26 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 160
ERROR - 2019-11-19 11:51:26 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 11:51:26 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 130
ERROR - 2019-11-19 11:51:26 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 133
ERROR - 2019-11-19 11:51:26 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 139
ERROR - 2019-11-19 11:51:26 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 145
ERROR - 2019-11-19 11:51:26 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 151
ERROR - 2019-11-19 11:51:26 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 160
ERROR - 2019-11-19 11:51:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:51:52 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 11:51:52 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 130
ERROR - 2019-11-19 11:51:52 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 133
ERROR - 2019-11-19 11:51:52 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 139
ERROR - 2019-11-19 11:51:52 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 145
ERROR - 2019-11-19 11:51:52 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 151
ERROR - 2019-11-19 11:51:52 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 160
ERROR - 2019-11-19 11:51:52 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 11:51:52 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 130
ERROR - 2019-11-19 11:51:52 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 133
ERROR - 2019-11-19 11:51:52 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 139
ERROR - 2019-11-19 11:51:52 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 145
ERROR - 2019-11-19 11:51:52 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 151
ERROR - 2019-11-19 11:51:52 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 160
ERROR - 2019-11-19 11:51:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:55:20 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/index.php 4
ERROR - 2019-11-19 11:55:50 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 11:55:50 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 11:55:50 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 11:55:50 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 11:55:50 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 11:55:50 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 11:55:50 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 11:55:50 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 11:55:50 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 11:55:50 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 11:55:50 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 11:55:50 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 11:55:50 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 11:55:50 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 11:55:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:56:06 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 11:56:06 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 11:56:06 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 11:56:06 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 11:56:06 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 11:56:06 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 11:56:06 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 11:56:06 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 11:56:06 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 11:56:06 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 11:56:06 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 11:56:06 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 11:56:06 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 11:56:06 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 11:56:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:56:22 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 11:56:22 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 11:56:22 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 11:56:22 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 11:56:22 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 11:56:22 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 11:56:22 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 11:56:22 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 11:56:22 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 11:56:22 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 11:56:22 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 11:56:22 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 11:56:22 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 11:56:22 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 11:56:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 11:58:55 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 11:58:55 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 130
ERROR - 2019-11-19 11:58:55 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 133
ERROR - 2019-11-19 11:58:55 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 139
ERROR - 2019-11-19 11:58:55 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 145
ERROR - 2019-11-19 11:58:55 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 151
ERROR - 2019-11-19 11:58:55 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 160
ERROR - 2019-11-19 11:58:55 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 11:58:55 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 130
ERROR - 2019-11-19 11:58:55 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 133
ERROR - 2019-11-19 11:58:55 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 139
ERROR - 2019-11-19 11:58:55 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 145
ERROR - 2019-11-19 11:58:55 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 151
ERROR - 2019-11-19 11:58:55 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 160
ERROR - 2019-11-19 11:58:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 12:01:43 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 12:01:43 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 12:01:43 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 12:01:43 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 12:01:43 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 12:01:43 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 12:01:43 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 12:01:43 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 12:01:43 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 12:01:43 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 12:01:43 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 12:01:43 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 12:01:43 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 12:01:43 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 12:01:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 12:01:52 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 12:01:52 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 12:01:52 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 12:01:52 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 12:01:52 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 12:01:52 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 12:01:52 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 12:01:52 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 12:01:52 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 12:01:52 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 12:01:52 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 12:01:52 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 12:01:52 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 12:01:52 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 12:01:59 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 12:01:59 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 12:01:59 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 12:01:59 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 12:01:59 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 12:01:59 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 12:01:59 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 12:01:59 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 12:01:59 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 12:01:59 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 12:01:59 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 12:01:59 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 12:01:59 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 12:01:59 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 12:02:31 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 12:02:31 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 12:02:31 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 12:02:31 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 12:02:31 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 12:02:31 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 12:02:31 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 12:02:31 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 12:02:31 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 12:02:31 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 12:02:31 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 12:02:31 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 12:02:31 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 12:02:31 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 12:02:37 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 12:02:37 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 12:02:37 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 12:02:37 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 12:02:37 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 12:02:37 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 12:02:37 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 12:02:37 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 12:02:37 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 12:02:37 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 12:02:37 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 12:02:37 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 12:02:37 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 12:02:37 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 12:07:37 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 12:07:37 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 12:07:37 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 12:07:37 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 12:07:37 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 12:07:37 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 12:07:37 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 12:07:37 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 12:07:37 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 12:07:37 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 12:07:37 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 12:07:37 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 12:07:37 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 12:07:37 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 12:07:48 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 12:07:48 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 12:07:48 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 12:07:48 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 12:07:48 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 12:07:48 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 12:07:48 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 12:07:48 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 12:07:48 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 12:07:48 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 12:07:48 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 12:07:48 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 12:07:48 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 12:07:48 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 12:09:25 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 12:09:25 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 12:09:25 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 12:09:25 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 12:09:25 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 12:09:25 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 12:09:25 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 12:09:25 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 12:09:25 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 12:09:25 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 12:09:25 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 12:09:25 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 12:09:25 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 12:09:25 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 12:15:32 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 12:15:32 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 12:15:32 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 12:15:32 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 12:15:32 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 12:15:32 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 12:15:32 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 12:15:32 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 12:15:32 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 12:15:32 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 12:15:32 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 12:15:32 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 12:15:32 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 12:15:32 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 12:15:47 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 12:15:47 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 12:15:47 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 12:15:47 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 12:15:47 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 12:15:47 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 12:15:47 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 12:15:47 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 12:15:47 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 12:15:47 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 12:15:47 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 12:15:47 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 12:15:47 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 12:15:47 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 12:16:06 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 12:16:06 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 12:16:06 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 12:16:06 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 12:16:06 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 12:16:06 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 12:16:06 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 12:16:06 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 12:16:06 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 12:16:06 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 12:16:06 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 12:16:06 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 12:16:06 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 12:16:06 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 12:16:12 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 12:16:12 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 12:16:12 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 12:16:12 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 12:16:12 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 12:16:12 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 12:16:12 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 12:16:12 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 116
ERROR - 2019-11-19 12:16:12 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 131
ERROR - 2019-11-19 12:16:12 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 134
ERROR - 2019-11-19 12:16:12 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 140
ERROR - 2019-11-19 12:16:12 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 146
ERROR - 2019-11-19 12:16:12 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 152
ERROR - 2019-11-19 12:16:12 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 161
ERROR - 2019-11-19 12:16:45 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 12:16:45 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 130
ERROR - 2019-11-19 12:16:45 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 133
ERROR - 2019-11-19 12:16:45 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 139
ERROR - 2019-11-19 12:16:45 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 145
ERROR - 2019-11-19 12:16:45 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 151
ERROR - 2019-11-19 12:16:45 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 160
ERROR - 2019-11-19 12:16:45 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 12:16:45 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 130
ERROR - 2019-11-19 12:16:45 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 133
ERROR - 2019-11-19 12:16:45 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 139
ERROR - 2019-11-19 12:16:45 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 145
ERROR - 2019-11-19 12:16:45 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 151
ERROR - 2019-11-19 12:16:45 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 160
ERROR - 2019-11-19 12:17:29 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 108
ERROR - 2019-11-19 12:17:57 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 12:17:57 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 130
ERROR - 2019-11-19 12:17:58 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 133
ERROR - 2019-11-19 12:17:58 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 139
ERROR - 2019-11-19 12:17:58 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 145
ERROR - 2019-11-19 12:17:58 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 151
ERROR - 2019-11-19 12:17:58 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 160
ERROR - 2019-11-19 12:17:58 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 12:17:58 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 130
ERROR - 2019-11-19 12:17:58 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 133
ERROR - 2019-11-19 12:17:58 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 139
ERROR - 2019-11-19 12:17:58 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 145
ERROR - 2019-11-19 12:17:58 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 151
ERROR - 2019-11-19 12:17:58 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 160
ERROR - 2019-11-19 12:18:33 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 12:18:33 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 130
ERROR - 2019-11-19 12:18:33 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 133
ERROR - 2019-11-19 12:18:33 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 139
ERROR - 2019-11-19 12:18:33 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 145
ERROR - 2019-11-19 12:18:33 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 151
ERROR - 2019-11-19 12:18:33 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 160
ERROR - 2019-11-19 12:18:33 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 12:18:33 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 130
ERROR - 2019-11-19 12:18:33 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 133
ERROR - 2019-11-19 12:18:33 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 139
ERROR - 2019-11-19 12:18:33 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 145
ERROR - 2019-11-19 12:18:33 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 151
ERROR - 2019-11-19 12:18:33 --> Severity: Notice --> Undefined index: teacher_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 160
ERROR - 2019-11-19 12:20:56 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 12:20:56 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 130
ERROR - 2019-11-19 12:20:56 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 133
ERROR - 2019-11-19 12:20:56 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 139
ERROR - 2019-11-19 12:20:56 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 145
ERROR - 2019-11-19 12:20:56 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 151
ERROR - 2019-11-19 12:20:56 --> Severity: Notice --> Undefined index: social_links /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 12:20:56 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 130
ERROR - 2019-11-19 12:20:56 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 133
ERROR - 2019-11-19 12:20:56 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 139
ERROR - 2019-11-19 12:20:56 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 145
ERROR - 2019-11-19 12:20:56 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 151
ERROR - 2019-11-19 12:37:44 --> Severity: error --> Exception: Cannot use object of type stdClass as array /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/teacher/edit.php 80
ERROR - 2019-11-19 12:37:54 --> Severity: error --> Exception: Cannot use object of type stdClass as array /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/teacher/edit.php 80
ERROR - 2019-11-19 12:38:14 --> Severity: error --> Exception: Cannot use object of type stdClass as array /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/teacher/edit.php 80
ERROR - 2019-11-19 12:39:16 --> Severity: error --> Exception: Cannot use object of type stdClass as array /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/teacher/edit.php 81
ERROR - 2019-11-19 12:39:27 --> Severity: error --> Exception: Cannot use object of type stdClass as array /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/teacher/edit.php 81
ERROR - 2019-11-19 12:42:16 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 12:42:16 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 129
ERROR - 2019-11-19 12:42:16 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 138
ERROR - 2019-11-19 12:42:16 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 144
ERROR - 2019-11-19 12:42:16 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 150
ERROR - 2019-11-19 12:42:16 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 12:42:16 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 129
ERROR - 2019-11-19 12:42:16 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 138
ERROR - 2019-11-19 12:42:16 --> Severity: Notice --> Trying to get property 'linkedin' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 144
ERROR - 2019-11-19 12:42:16 --> Severity: Notice --> Trying to get property 'twitter' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 150
ERROR - 2019-11-19 12:42:42 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 12:42:42 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 129
ERROR - 2019-11-19 12:42:42 --> Severity: Notice --> Undefined variable: user /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 115
ERROR - 2019-11-19 12:42:42 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 129
ERROR - 2019-11-19 12:42:59 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 129
ERROR - 2019-11-19 12:42:59 --> Severity: Notice --> Undefined index: designation /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/home.php 129
ERROR - 2019-11-19 12:43:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 12:43:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-19 13:08:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 13:08:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 13:08:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-19 13:16:00 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'about_us_image'
ERROR - 2019-11-19 13:18:23 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'about_us'
ERROR - 2019-11-19 13:23:23 --> Severity: error --> Exception: Call to undefined function manager() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Home.php 47
ERROR - 2019-11-19 13:24:27 --> Query error: Table 'ekattor_7.teacher' doesn't exist - Invalid query: SELECT *
FROM `teacher`
WHERE `show_on_website` = 1
ERROR - 2019-11-19 13:37:09 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 68
ERROR - 2019-11-19 13:37:09 --> Severity: error --> Exception: Cannot use object of type stdClass as array /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 74
ERROR - 2019-11-19 13:37:14 --> Severity: Notice --> Undefined index: about /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 68
ERROR - 2019-11-19 13:37:14 --> Severity: error --> Exception: Cannot use object of type stdClass as array /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 74
ERROR - 2019-11-19 13:37:26 --> Severity: error --> Exception: Cannot use object of type stdClass as array /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 74
ERROR - 2019-11-19 13:37:46 --> Severity: Notice --> Undefined index: user_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 95
ERROR - 2019-11-19 13:37:47 --> Severity: Notice --> Undefined index: user_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 95
ERROR - 2019-11-19 13:37:47 --> Severity: Notice --> Undefined index: user_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 95
ERROR - 2019-11-19 13:37:47 --> Severity: Notice --> Undefined index: user_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 95
ERROR - 2019-11-19 13:37:47 --> Severity: Notice --> Undefined index: user_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 95
ERROR - 2019-11-19 13:37:47 --> Severity: Notice --> Undefined index: user_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 95
ERROR - 2019-11-19 13:37:47 --> Severity: Notice --> Undefined index: user_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 95
ERROR - 2019-11-19 13:37:47 --> Severity: Notice --> Undefined index: user_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 95
ERROR - 2019-11-19 13:37:47 --> Severity: Notice --> Undefined index: user_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 95
ERROR - 2019-11-19 13:37:47 --> Severity: Notice --> Undefined index: user_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 95
ERROR - 2019-11-19 13:37:47 --> Severity: Notice --> Undefined index: user_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 95
ERROR - 2019-11-19 13:37:47 --> Severity: Notice --> Undefined index: user_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 95
ERROR - 2019-11-19 13:37:49 --> Severity: Notice --> Undefined index: user_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 95
ERROR - 2019-11-19 13:37:49 --> Severity: Notice --> Undefined index: user_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 95
ERROR - 2019-11-19 13:37:49 --> Severity: Notice --> Undefined index: user_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 95
ERROR - 2019-11-19 13:37:49 --> Severity: Notice --> Undefined index: user_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 95
ERROR - 2019-11-19 13:37:49 --> Severity: Notice --> Undefined index: user_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 95
ERROR - 2019-11-19 13:37:49 --> Severity: Notice --> Undefined index: user_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 95
ERROR - 2019-11-19 13:37:49 --> Severity: Notice --> Undefined index: user_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 95
ERROR - 2019-11-19 13:37:49 --> Severity: Notice --> Undefined index: user_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 95
ERROR - 2019-11-19 13:37:49 --> Severity: Notice --> Undefined index: user_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 95
ERROR - 2019-11-19 13:37:49 --> Severity: Notice --> Undefined index: user_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 95
ERROR - 2019-11-19 13:37:49 --> Severity: Notice --> Undefined index: user_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 95
ERROR - 2019-11-19 13:37:49 --> Severity: Notice --> Undefined index: user_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/teacher.php 95
