<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-19 06:21:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-19 06:21:45 --> Unable to connect to the database
ERROR - 2019-12-19 09:12:24 --> Severity: error --> Exception: syntax error, unexpected '==' (T_IS_EQUAL), expecting ')' /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 795
ERROR - 2019-12-19 15:12:40 --> Severity: Notice --> Undefined property: Superadmin::$view /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 798
ERROR - 2019-12-19 15:12:40 --> Severity: error --> Exception: Call to a member function load() on null /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 798
ERROR - 2019-12-19 15:50:51 --> Severity: Warning --> mb_detect_encoding() expects parameter 1 to be string, object given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/libraries/dompdf/src/Dompdf.php 424
ERROR - 2019-12-19 15:50:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/libraries/dompdf/src/Dompdf.php 428
ERROR - 2019-12-19 15:50:51 --> Severity: Warning --> mb_convert_encoding(): Illegal character encoding specified /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/libraries/dompdf/src/Dompdf.php 428
ERROR - 2019-12-19 15:50:56 --> Severity: Warning --> mb_detect_encoding() expects parameter 1 to be string, object given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/libraries/dompdf/src/Dompdf.php 424
ERROR - 2019-12-19 15:50:56 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/libraries/dompdf/src/Dompdf.php 428
ERROR - 2019-12-19 15:50:56 --> Severity: Warning --> mb_convert_encoding(): Illegal character encoding specified /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/libraries/dompdf/src/Dompdf.php 428
ERROR - 2019-12-19 16:33:50 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 801
ERROR - 2019-12-19 17:40:29 --> Severity: Warning --> Use of undefined constant ABSPATH - assumed 'ABSPATH' (this will throw an Error in a future version of PHP) /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/invoice/pdf.php 12
ERROR - 2019-12-19 17:46:15 --> Severity: Notice --> Undefined variable: page_title /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/invoice/pdf.php 4
ERROR - 2019-12-19 11:55:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-19 12:18:09 --> Severity: error --> Exception: syntax error, unexpected '}' /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 832
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Notice --> Undefined variable: line /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 18:18:19 --> Severity: Warning --> fputcsv() expects parameter 2 to be array, null given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 831
ERROR - 2019-12-19 19:27:02 --> Severity: error --> Exception: Call to undefined method Pdf::setOption() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 817
ERROR - 2019-12-19 19:28:14 --> Severity: error --> Exception: Call to undefined method Pdf::setOption() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 818
ERROR - 2019-12-19 13:44:43 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:43 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:43 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:43 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:43 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:43 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:43 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:43 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:44 --> 404 Page Not Found: Uploads/system
ERROR - 2019-12-19 13:44:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:44:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:45:06 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:06 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:06 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:06 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:06 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:06 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:06 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:06 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:06 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:06 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:06 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:06 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:06 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:06 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:06 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:06 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:06 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:06 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:06 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:06 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:06 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:06 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:06 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:07 --> Severity: Notice --> Undefined index: timezone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-12-19 13:45:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:45:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:45:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:45:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:45:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:45:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:45:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:45:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:45:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:45:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:45:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:45:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:52:08 --> 404 Page Not Found: I/index
ERROR - 2019-12-19 13:52:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:52:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:52:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:52:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:52:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:52:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:52:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:52:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:52:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:52:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:52:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:52:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:52:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:52:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:52:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-19 13:52:13 --> 404 Page Not Found: Assets/js
