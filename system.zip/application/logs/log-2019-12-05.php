<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-05 06:47:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-05 06:47:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-05 06:47:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-05 06:48:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-05 07:00:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-05 07:56:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-05 07:56:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-05 08:40:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-05 08:40:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-05 12:26:17 --> 404 Page Not Found: addons/Alumni/apps-projects-details.html
